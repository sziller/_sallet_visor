from sqlalchemy import Column, Integer, String, JSON, Float, DateTime
from sqlalchemy.ext.declarative import declarative_base
import time
from cryptography import HashFunctions as HaFu
from datetime import datetime

Base = declarative_base()


class DLC(Base):
    """=== Classname: DLC(Base) =========================================================================================
    Class represents a Discreet Log Contract (DLC) lifecycle to be stored and processed by the DB
    ============================================================================================== by Sziller ==="""
    __tablename__ = "dlcs"
    dlc_id: str                             = Column("dlc_id", String, primary_key=True)
    temporary_contract_id: str              = Column("temporary_contract_id", String)
    initiator_email: str                    = Column("initiator_email", String)
    initiator_pubkey: str                   = Column("initiator_pubkey", String)
    acceptor_email: str                     = Column("acceptor_email", String, nullable=True)
    acceptor_pubkey: str                    = Column("acceptor_pubkey", String, nullable=True)
    oracle_id: str                          = Column("oracle_id", String)
    contract_terms: dict                    = Column("contract_terms", JSON)
    status: str                             = Column("status", String, default="created")
    initiator_signatures: dict              = Column("initiator_signatures", JSON, nullable=True)
    acceptor_signatures: dict               = Column("acceptor_signatures", JSON, nullable=True)
    funding_inputs: dict                    = Column("funding_inputs", JSON, nullable=True)
    funding_txid: str                       = Column("funding_txid", String, nullable=True)
    outcome_txid: str                       = Column("outcome_txid", String, nullable=True)
    created_at: float                       = Column("created_at", Float)
    updated_at: float                       = Column("updated_at", Float)
    timeout_at: float                       = Column("timeout_at", Float, nullable=True)

    def __init__(self,
                 temporary_contract_id: str,
                 initiator_email: str,
                 initiator_pubkey: str,
                 oracle_id: str,
                 contract_terms: dict,
                 created_at: float          = 0,
                 updated_at: float          = 0,
                 timeout_at: float          = None,
                 status: str                = "created",
                 acceptor_email: str        = None,
                 acceptor_pubkey: str       = None,
                 initiator_signatures: dict = None,
                 acceptor_signatures: dict  = None,
                 funding_inputs: dict       = None,
                 funding_txid: str          = None,
                 outcome_txid: str          = None):
        self.temporary_contract_id          = temporary_contract_id
        self.initiator_email                = initiator_email
        self.initiator_pubkey               = initiator_pubkey
        self.oracle_id                      = oracle_id
        self.contract_terms                 = contract_terms
        self.status                         = status
        self.acceptor_email                 = acceptor_email
        self.acceptor_pubkey                = acceptor_pubkey
        self.initiator_signatures           = initiator_signatures or {}
        self.acceptor_signatures            = acceptor_signatures or {}
        self.funding_inputs                 = funding_inputs or {}
        self.funding_txid                   = funding_txid
        self.outcome_txid                   = outcome_txid
        self.created_at                     = created_at if created_at else time.time()
        self.updated_at                     = updated_at if updated_at else time.time()
        self.timeout_at                     = timeout_at
        # Generate dlc_id after all attributes are initialized
        self.dlc_id                         = self.generate_id_hash()

    def generate_id_hash(self):
        """Function generates a unique ID for the DLC row"""
        return HaFu.single_sha256_byte2byte(bytes(
            f"{self.temporary_contract_id}{self.created_at}",
            "utf-8")).hex()[:16]

    def return_as_dict(self):
        """Returns instance as a dictionary"""
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}

    @classmethod
    def construct(cls, d_in):
        """Constructs an instance of the class from a dictionary"""
        return cls(**d_in)

    def __repr__(self):
        return (f"DLC ID: {self.dlc_id} | Status: {self.status} | "
                f"Initiator: {self.initiator_email} | "
                f"Acceptor: {self.acceptor_email if self.acceptor_email else 'N/A'}")
